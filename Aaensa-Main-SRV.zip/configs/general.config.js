const generalConfig = {
    port: 3000,
};

module.exports = generalConfig;